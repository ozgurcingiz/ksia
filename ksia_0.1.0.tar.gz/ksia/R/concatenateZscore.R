#' @export
concatenateZscore <- function(data)
{
  # this representation (missing transpose t() function) rows are genes, columns are samples
  # transpose'a gerek yok. transpose concenate fonksiyonunda zaten transpose aliniyor. colum gene, row sample oldugunda.
  mimS <- build.mim(t(data),estimator="spearman");
  mimS=zscore(mimS);

  mimP <- build.mim(t(data),estimator="pearson");
  mimP=zscore(mimP);


  # coefS= cor(t(data),method="spearman");
  #coefS=zscore(coefS);


  mim=(mimS^2 + mimP^2)^0.5;

  mim



}
