#' @export
concatenateZscore <- function(data,method="ssos")
{
  # this representation (missing transpose t() function) rows are genes, columns are samples
  # transpose'a gerek yok. transpose concenate fonksiyonunda zaten transpose aliniyor. colum gene, row sample oldugunda.
  mimS <- build.mim(t(data),estimator="spearman");
  mimS=zscore(mimS);


  coefS <- build.mim(t(data),estimator="pearson");
  coefS=zscore(coefS);

  if(method=="ssos")
  {
    mim=(mimS^2 + coefS^2)^0.5;
  }
  else if (method =="average")
  {
    mim= (mimS+coefS)/2;
  }
  else if (method=="mul")
  {
    mim=(mimS^2 + coefS^2)
  }
  else
  {
    print("please enter sos, average or ss to obtain combined z-score");
  }

  mim



}
