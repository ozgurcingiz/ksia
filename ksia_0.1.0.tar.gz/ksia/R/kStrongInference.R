#' @export
kStrongInference <- function (mim, sym = TRUE,k=3)
{

  library("c3net");
  library("minet");

  diag(mim) <- 0
  mim=aracne(mim); # burda ilk adim
  ksi <- mim
  ksi[, ] <- 0
  numgene <- ncol(mim)

  if (sym == TRUE) {
    for (i in 1:numgene) {
      if (sum(mim[i, ]) != 0) {
        #ind <- which(mim[i, ] == max(mim[i, ]))[1]
        ind= sort(mim[i,],decreasing = TRUE, index.return=TRUE)$ix[1:k]
        #filtInd=which(ind>0 & is.na(ind)==FALSE);
        filtInd=which(mim[i,ind]>0 & is.na(mim[i,ind])==FALSE);
        ind=ind[filtInd]
        ksi[i, ind] <- mim[i, ind]
        ksi[ind, i] <- mim[i, ind]
      }
    }
  }
  if (sym != TRUE) {
    for (i in 1:numgene) {
      if (sum(mim[i, ]) != 0) {
        #ind <- which(mim[i, ] == max(mim[i, ]))[1]
        ind= sort(mim[i,],decreasing = TRUE,index.return=TRUE)$ix[1:k]
        #filtInd=which(ind>0 & is.na(ind)==FALSE);
        filtInd=which(mim[i,ind]>0 & is.na(mim[i,ind])==FALSE);
        ind=ind[filtInd]
        ksi[i, ind] <- mim[i, ind]
      }
    }
  }

  ksi[ksi >0] <-1
  ksi

}
