#' @export
zscore<- function(datam){

   diag(datam)=0;

   geneC= ncol(datam);
   datam=as.matrix(datam);
   datamTemp=datam;

   for (i in 1:(geneC-1))
   {
      meanT=mean(datam[i,]);
      sdT=sd(datam[i,]);



      for (j in (i+1):geneC )
      {

         meanC=mean(datam[,j]);
         sdC=sd(datam[,j]);


         rowBasedResult= (datam[i,j] - meanT) / sdT;
         if(rowBasedResult<0)
         {
            rowBasedResult= 0;
         }


         columnBasedResult= (datam[i,j] - meanC) / sdC;

         if(columnBasedResult<0)
         {
            columnBasedResult= 0;
         }


         fresult= (rowBasedResult^2 + columnBasedResult^2)^0.5;
         datamTemp[i,j]=fresult;
         datamTemp[j,i]=fresult;

      }

      datamTemp
   }


   return (datamTemp);


}
