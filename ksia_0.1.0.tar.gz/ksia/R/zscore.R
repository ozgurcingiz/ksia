#' @export
zscore<- function(datam){

   diag(datam)=0;

   geneC= ncol(datam)
   datamTemp=datam;



   for (i in 1:(geneC-1) )
   {
         meanT= mean(datam[i,]);
         stdT=sd(datam[i,]);

      for (j in (i+1):geneC )
      {
         datamTemp[i,j]=(datam[i,j] - meanT ) / stdT ;
         datamTemp[j,i]=datamTemp[i,j];

      }


   }
   return (datamTemp);

  # z<- (x - mean(x)) / sd(x)
  # return(z)
  #

   # datam=scale(datam);
  #datam


}
